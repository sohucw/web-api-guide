'use strict';

var _jQuery = jQuery,
    _jqLiteMode = false;
